# # main.py  manappuram

# import streamlit as st
# import pandas as pd
# import numpy as np
# import os
# import pickle
# from keras.models import load_model
# from transformers import T5Tokenizer, T5ForConditionalGeneration
# import torch

# # ----------------------------
# # CONFIGURATION & THEME
# # ----------------------------
# st.set_page_config(page_title="\U0001F4CA NBFC Risk Predictor", layout="wide", page_icon="\U0001F4C8")

# st.markdown("""
#     <style>
#         body {
#             background-color: #f9f9f9;
#             font-family: 'Segoe UI', sans-serif;
#         }
#         .main-title {
#             text-align: center;
#             color: #004080;
#             font-size: 36px;
#             margin-bottom: 10px;
#         }
#         .subtitle {
#             text-align: center;
#             font-size: 20px;
#             color: #666;
#             margin-bottom: 30px;
#         }
#         .stButton > button {
#             background-color: #004080;
#             color: white;
#             border-radius: 8px;
#             padding: 0.5em 2em;
#             font-weight: bold;
#         }
#         .stDownloadButton > button {
#             background-color: #008060;
#             color: white;
#             border-radius: 8px;
#             padding: 0.5em 2em;
#             font-weight: bold;
#         }
#         .success {
#             background-color: #d4edda;
#             padding: 15px;
#             border-left: 6px solid #28a745;
#             border-radius: 5px;
#         }
#         .info-card {
#             background-color: #e8f0fe;
#             padding: 20px;
#             border-radius: 10px;
#             border-left: 6px solid #4285F4;
#             margin-bottom: 20px;
#         }
#     </style>
# """, unsafe_allow_html=True)

# st.markdown("<div class='main-title'>\U0001F4CA NBFC Risk Predictor + \U0001F9E0 Auto Summary</div>", unsafe_allow_html=True)
# st.markdown("<div class='subtitle'>Upload customer data, analyze risks, and view actionable insights!</div>", unsafe_allow_html=True)

# st.sidebar.image("https://cdn-icons-png.flaticon.com/512/1077/1077114.png", width=100)
# st.sidebar.markdown("### \U0001F4C1 Upload customer dataset Of Manappuram Finance")
# uploaded_file = st.sidebar.file_uploader("Upload a CSV or Excel file", type=["csv", "xlsx"])

# @st.cache_resource
# def load_flan_model():
#     tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-base")
#     model = T5ForConditionalGeneration.from_pretrained("google/flan-t5-base")
#     return tokenizer, model

# tokenizer, flan_model = load_flan_model()

# risk_model = load_model("risk_model.h5")
# scaler = pickle.load(open("scaler.pkl", "rb"))
# kmeans = pickle.load(open("kmeans.pkl", "rb"))
# label_encoders = pickle.load(open("label_encoders.pkl", "rb"))
# features_list = pickle.load(open("features_list.pkl", "rb"))

# categorical_cols = [
#     "EMI_PERSON_GENDER", "LOCALITY", "STATE_NAME", "BRANCH_NAME",
#     "REGION_NAME", "TOPUP_LOAN_ORNOT", "CUSTOMER_PROFILE", "ENDUSE"
# ]

# def classify_risk(prob):
#     if prob <= 0.3:
#         return 0
#     elif prob <= 0.7:
#         return 1
#     else:
#         return 2

# def recommend_action(risk, cluster):
#     if risk == 2:
#         return "Legal Action"
#     elif risk == 1:
#         return ["Visit Customer", "Call Customer", "Send SMS Reminder"][cluster]
#     else:
#         return ["Send SMS Reminder", "Call Customer", "No Action Needed"][cluster]

# def safe_transform(le, value):
#     if value in le.classes_:
#         return le.transform([value])[0]
#     if 'Other' not in le.classes_:
#         le.classes_ = np.append(le.classes_, 'Other')
#     return le.transform(['Other'])[0]

# def generate_summary(df):
#     total = df.shape[0]
#     risk_counts = df['predicted_risk'].value_counts().to_dict()

#     high_risk = risk_counts.get('High', 0)
#     med_risk = risk_counts.get('Medium', 0)
#     low_risk = risk_counts.get('Low', 0)

#     high_risk_percent = round(high_risk / total * 100, 1)
#     med_risk_percent = round(med_risk / total * 100, 1)
#     low_risk_percent = round(low_risk / total * 100, 1)

#     high_loan_amt_count = df[df['LOAN_AMOUNT'] > 500000].shape[0] if 'LOAN_AMOUNT' in df else 0
#     most_high_risk_cluster = df[df['predicted_risk'] == 'High']['cluster'].mode()[0]

#     def get_top(col, risk_type):
#         if col in df.columns:
#             subset = df[df['predicted_risk'] == risk_type]
#             return subset[col].mode()[0] if not subset[col].empty else "N/A"
#         return "N/A"

#     top_high_state = get_top("STATE_NAME", "High")
#     top_med_state = get_top("STATE_NAME", "Medium")
#     top_low_state = get_top("STATE_NAME", "Low")

#     top_high_region = get_top("REGION_NAME", "High")
#     top_med_region = get_top("REGION_NAME", "Medium")
#     top_low_region = get_top("REGION_NAME", "Low")

#     top_high_branch = get_top("BRANCH_NAME", "High")
#     top_med_branch = get_top("BRANCH_NAME", "Medium")
#     top_low_branch = get_top("BRANCH_NAME", "Low")

#     summary = f"""
#     <div class='info-card'>
#     <b>\U0001F4CA Summary Report:</b><br><br>
#     Out of <b>{total}</b> customers analyzed:<br>
#     🔵 <b>{low_risk_percent}%</b> are classified as Low Risk<br>
#     🟡 <b>{med_risk_percent}%</b> as Medium Risk<br>
#     🔴 <b>{high_risk_percent}%</b> as High Risk<br><br>
#     💰 <b>{high_loan_amt_count}</b> customers have loan amounts over ₹5 Lakhs<br><br>
#     ⚠ Cluster <b>{most_high_risk_cluster}</b> has the highest number of High Risk customers — Suggested: <span style='color:red;'><b>Legal Action</b></span><br><br>

#     📍 <b>Top Locations by Risk:</b><br>
#     🔴 High Risk → State: <b>{top_high_state}</b>, Region: <b>{top_high_region}</b>, Branch: <b>{top_high_branch}</b><br>
#     🟡 Medium Risk → State: <b>{top_med_state}</b>, Region: <b>{top_med_region}</b>, Branch: <b>{top_med_branch}</b><br>
#     🔵 Low Risk → State: <b>{top_low_state}</b>, Region: <b>{top_low_region}</b>, Branch: <b>{top_low_branch}</b><br>
#     </div>
#     """
#     return summary, high_risk_percent, med_risk_percent, low_risk_percent, high_loan_amt_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch

# def generate_conclusion(high_risk_percent, high_balance_count, most_high_risk_cluster, top_state_high, top_region_high, top_branch_high):
#     def get_top_location(risk_label, column):
#         return (
#             input_df[input_df['predicted_risk'] == risk_label][column].mode().iloc[0]
#             if column in input_df.columns and not input_df[input_df['predicted_risk'] == risk_label][column].empty
#             else "Unknown"
#         )

#     top_state_low = get_top_location('Low', 'STATE_NAME')
#     top_region_low = get_top_location('Low', 'REGION_NAME')
#     top_branch_low = get_top_location('Low', 'BRANCH_NAME')

#     conclusion = f"""
#     <div class='info-card' style='border-left:6px solid #dc3545;background-color:#f8d7da;'>
#     <b>\U0001F9FE Conclusion & Strategic Suggestions:</b><br><br>

#     <b>📌 High Risk Focus:</b><br>
#     🔴 <b>{high_risk_percent}%</b> customers are in the High Risk category.<br>
#     ➔ Concentrated in <b>State:</b> {top_state_high}, <b>Region:</b> {top_region_high}, <b>Branch:</b> {top_branch_high}.<br>
#     ➔ Recommend <b>legal notices, recovery actions, and field visits</b> for Cluster <b>{most_high_risk_cluster}</b>.<br><br>

#     <b>💰 High Loan Exposure:</b><br>
#     ➔ <b>{high_balance_count}</b> customers have loans over ₹5 Lakhs. Prioritize for <b>collection, restructuring, or review.</b><br><br>

#     <b>✅ Low Risk Opportunities:</b><br>
#     ➔ Strong performance in <b>State:</b> {top_state_low}, <b>Region:</b> {top_region_low}, <b>Branch:</b> {top_branch_low}.<br>
#     ➔ Suggest targeting these zones for <b>cross-selling, top-up offers, or digital engagement.</b><br><br>


#     <b>🛡️ Actionable Tips:</b><br>
#     • Audit high-risk branches more frequently<br>
#     • Deploy dedicated recovery teams in risk-heavy zones<br>
#     • Enhance pre-loan checks and digital verification<br><br>

#     <b>📈 Business Impact:</b><br>
#     Proactive targeting improves <b>portfolio quality</b>, <b>reduces defaults</b>, and <b>increases recovery efficiency</b>.
#     </div>
#     """
#     return conclusion

# if uploaded_file:
#     st.markdown("<div class='success'>✅ File uploaded successfully. Running predictions...</div>", unsafe_allow_html=True)
#     input_df = pd.read_csv(uploaded_file) if uploaded_file.name.endswith(".csv") else pd.read_excel(uploaded_file)
#     st.markdown("### \U0001F4C4 Uploaded Data Preview")
#     st.dataframe(input_df.head(), use_container_width=True)

#     df = input_df.copy()
#     for col in categorical_cols:
#         df[col] = df[col].apply(lambda x: safe_transform(label_encoders[col], x))

#     for col in features_list:
#         if col not in df.columns:
#             df[col] = 0
#     df_features = df[features_list]

#     scaled = scaler.transform(df_features)
#     risk_probs = risk_model.predict(scaled).flatten()
#     risks = [classify_risk(p) for p in risk_probs]
#     clusters = kmeans.predict(scaled)
#     actions = [recommend_action(r, c) for r, c in zip(risks, clusters)]

#     input_df['predicted_risk'] = [ ["Low", "Medium", "High"][r] for r in risks ]
#     input_df['risk'] = risks
#     input_df['cluster'] = clusters
#     input_df['recommended_action'] = actions

#     st.session_state["predicted_data"] = input_df
#     st.session_state["risk_df"] = input_df

#     st.markdown("### ✅ Prediction Results")
#     st.dataframe(input_df, use_container_width=True)

#     st.markdown("### \U0001F9E0 Auto Summary")
#     summary_html, high_risk_percent, med_risk_percent, low_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch = generate_summary(input_df)
#     st.markdown(summary_html, unsafe_allow_html=True)

#     conclusion_html = generate_conclusion(high_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch)
#     st.markdown(conclusion_html, unsafe_allow_html=True)

#     st.download_button("⬇️ Download Prediction CSV", data=input_df.to_csv(index=False).encode("utf-8"), file_name="risk_output.csv")

# else:
#     st.markdown("### 🚀 Let's Get Started")
#     st.markdown("Upload a customer dataset from the sidebar to begin prediction, analysis, and summary generation.")

# main.py  (Manappuram NBFC Risk Predictor)

# import streamlit as st
# import pandas as pd
# import numpy as np
# import os
# import pickle
# from keras.models import load_model
# from transformers import T5Tokenizer, T5ForConditionalGeneration
# import torch

# # ----------------------------
# # SESSION INITIALIZATION
# # ----------------------------
# if 'predicted_data' not in st.session_state:
#     st.session_state.predicted_data = None

# if 'risk_df' not in st.session_state:
#     st.session_state.risk_df = None

# # ----------------------------
# # CONFIGURATION & THEME
# # ----------------------------
# st.set_page_config(page_title="\U0001F4CA NBFC Risk Predictor", layout="wide", page_icon="\U0001F4C8")

# st.markdown("""
#     <style>
#         body {
#             background-color: #f9f9f9;
#             font-family: 'Segoe UI', sans-serif;
#         }
#         .main-title {
#             text-align: center;
#             color: #004080;
#             font-size: 36px;
#             margin-bottom: 10px;
#         }
#         .subtitle {
#             text-align: center;
#             font-size: 20px;
#             color: #666;
#             margin-bottom: 30px;
#         }
#         .stButton > button {
#             background-color: #004080;
#             color: white;
#             border-radius: 8px;
#             padding: 0.5em 2em;
#             font-weight: bold;
#         }
#         .stDownloadButton > button {
#             background-color: #008060;
#             color: white;
#             border-radius: 8px;
#             padding: 0.5em 2em;
#             font-weight: bold;
#         }
#         .success {
#             background-color: #d4edda;
#             padding: 15px;
#             border-left: 6px solid #28a745;
#             border-radius: 5px;
#         }
#         .info-card {
#             background-color: #e8f0fe;
#             padding: 20px;
#             border-radius: 10px;
#             border-left: 6px solid #4285F4;
#             margin-bottom: 20px;
#         }
#     </style>
# """, unsafe_allow_html=True)

# st.markdown("<div class='main-title'>\U0001F4CA NBFC Risk Predictor + \U0001F9E0 Auto Summary</div>", unsafe_allow_html=True)
# st.markdown("<div class='subtitle'>Upload customer data, analyze risks, and view actionable insights!</div>", unsafe_allow_html=True)

# st.sidebar.image("https://cdn-icons-png.flaticon.com/512/1077/1077114.png", width=100)
# st.sidebar.markdown("### \U0001F4C1 Upload customer dataset Of Manappuram Finance")
# uploaded_file = st.sidebar.file_uploader("Upload a CSV or Excel file", type=["csv", "xlsx"])

# @st.cache_resource
# def load_flan_model():
#     tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-base")
#     model = T5ForConditionalGeneration.from_pretrained("google/flan-t5-base")
#     return tokenizer, model

# tokenizer, flan_model = load_flan_model()

# risk_model = load_model("risk_model.h5")
# scaler = pickle.load(open("scaler.pkl", "rb"))
# kmeans = pickle.load(open("kmeans.pkl", "rb"))
# label_encoders = pickle.load(open("label_encoders.pkl", "rb"))
# features_list = pickle.load(open("features_list.pkl", "rb"))

# categorical_cols = [
#     "EMI_PERSON_GENDER", "LOCALITY", "STATE_NAME", "BRANCH_NAME",
#     "REGION_NAME", "TOPUP_LOAN_ORNOT", "CUSTOMER_PROFILE", "ENDUSE"
# ]

# def classify_risk(prob):
#     if prob <= 0.3:
#         return 0
#     elif prob <= 0.7:
#         return 1
#     else:
#         return 2

# def recommend_action(risk, cluster):
#     if risk == 2:
#         return "Legal Action"
#     elif risk == 1:
#         return ["Visit Customer", "Call Customer", "Send SMS Reminder"][cluster]
#     else:
#         return ["Send SMS Reminder", "Call Customer", "No Action Needed"][cluster]

# def safe_transform(le, value):
#     if value in le.classes_:
#         return le.transform([value])[0]
#     if 'Other' not in le.classes_:
#         le.classes_ = np.append(le.classes_, 'Other')
#     return le.transform(['Other'])[0]

# def generate_summary(df):
#     total = df.shape[0]
#     risk_counts = df['predicted_risk'].value_counts().to_dict()

#     high_risk = risk_counts.get('High', 0)
#     med_risk = risk_counts.get('Medium', 0)
#     low_risk = risk_counts.get('Low', 0)

#     high_risk_percent = round(high_risk / total * 100, 1)
#     med_risk_percent = round(med_risk / total * 100, 1)
#     low_risk_percent = round(low_risk / total * 100, 1)

#     high_loan_amt_count = df[df['LOAN_AMOUNT'] > 500000].shape[0] if 'LOAN_AMOUNT' in df else 0
#     most_high_risk_cluster = df[df['predicted_risk'] == 'High']['cluster'].mode()[0]

#     def get_top(col, risk_type):
#         if col in df.columns:
#             subset = df[df['predicted_risk'] == risk_type]
#             return subset[col].mode()[0] if not subset[col].empty else "N/A"
#         return "N/A"

#     top_high_state = get_top("STATE_NAME", "High")
#     top_med_state = get_top("STATE_NAME", "Medium")
#     top_low_state = get_top("STATE_NAME", "Low")

#     top_high_region = get_top("REGION_NAME", "High")
#     top_med_region = get_top("REGION_NAME", "Medium")
#     top_low_region = get_top("REGION_NAME", "Low")

#     top_high_branch = get_top("BRANCH_NAME", "High")
#     top_med_branch = get_top("BRANCH_NAME", "Medium")
#     top_low_branch = get_top("BRANCH_NAME", "Low")

#     summary = f"""
#     <div class='info-card'>
#     <b>\U0001F4CA Summary Report:</b><br><br>
#     Out of <b>{total}</b> customers analyzed:<br>
#     🔵 <b>{low_risk_percent}%</b> are classified as Low Risk<br>
#     🟡 <b>{med_risk_percent}%</b> as Medium Risk<br>
#     🔴 <b>{high_risk_percent}%</b> as High Risk<br><br>
#     💰 <b>{high_loan_amt_count}</b> customers have loan amounts over ₹5 Lakhs<br><br>
#     ⚠ Cluster <b>{most_high_risk_cluster}</b> has the highest number of High Risk customers — Suggested: <span style='color:red;'><b>Legal Action</b></span><br><br>

#     📍 <b>Top Locations by Risk:</b><br>
#     🔴 High Risk → State: <b>{top_high_state}</b>, Region: <b>{top_high_region}</b>, Branch: <b>{top_high_branch}</b><br>
#     🟡 Medium Risk → State: <b>{top_med_state}</b>, Region: <b>{top_med_region}</b>, Branch: <b>{top_med_branch}</b><br>
#     🔵 Low Risk → State: <b>{top_low_state}</b>, Region: <b>{top_low_region}</b>, Branch: <b>{top_low_branch}</b><br>
#     </div>
#     """
#     return summary, high_risk_percent, med_risk_percent, low_risk_percent, high_loan_amt_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch

# def generate_conclusion(high_risk_percent, high_balance_count, most_high_risk_cluster, top_state_high, top_region_high, top_branch_high):
#     def get_top_location(risk_label, column):
#         return (
#             input_df[input_df['predicted_risk'] == risk_label][column].mode().iloc[0]
#             if column in input_df.columns and not input_df[input_df['predicted_risk'] == risk_label][column].empty
#             else "Unknown"
#         )

#     top_state_low = get_top_location('Low', 'STATE_NAME')
#     top_region_low = get_top_location('Low', 'REGION_NAME')
#     top_branch_low = get_top_location('Low', 'BRANCH_NAME')

#     conclusion = f"""
#     <div class='info-card' style='border-left:6px solid #dc3545;background-color:#f8d7da;'>
#     <b>\U0001F9FE Conclusion & Strategic Suggestions:</b><br><br>

#     <b>📌 High Risk Focus:</b><br>
#     🔴 <b>{high_risk_percent}%</b> customers are in the High Risk category.<br>
#     ➔ Concentrated in <b>State:</b> {top_state_high}, <b>Region:</b> {top_region_high}, <b>Branch:</b> {top_branch_high}.<br>
#     ➔ Recommend <b>legal notices, recovery actions, and field visits</b> for Cluster <b>{most_high_risk_cluster}</b>.<br><br>

#     <b>💰 High Loan Exposure:</b><br>
#     ➔ <b>{high_balance_count}</b> customers have loans over ₹5 Lakhs. Prioritize for <b>collection, restructuring, or review.</b><br><br>

#     <b>✅ Low Risk Opportunities:</b><br>
#     ➔ Strong performance in <b>State:</b> {top_state_low}, <b>Region:</b> {top_region_low}, <b>Branch:</b> {top_branch_low}.<br>
#     ➔ Suggest targeting these zones for <b>cross-selling, top-up offers, or digital engagement.</b><br><br>

#     <b>🛡️ Actionable Tips:</b><br>
#     • Audit high-risk branches more frequently<br>
#     • Deploy dedicated recovery teams in risk-heavy zones<br>
#     • Enhance pre-loan checks and digital verification<br><br>

#     <b>📈 Business Impact:</b><br>
#     Proactive targeting improves <b>portfolio quality</b>, <b>reduces defaults</b>, and <b>increases recovery efficiency</b>.
#     </div>
#     """
#     return conclusion

# # (Your code above remains unchanged...)

# # ⬇️ Your original block: upload file + process
# if uploaded_file:
#     st.markdown("<div class='success'>✅ File uploaded successfully. Running predictions...</div>", unsafe_allow_html=True)
#     #input_df = pd.read_csv(uploaded_file) if uploaded_file.name.endswith(".csv") else pd.read_excel(uploaded_file)
#     input_df = pd.read_csv(uploaded_file) if uploaded_file.name.endswith(".csv") else pd.read_excel(uploaded_file)
#     st.session_state["original_input_df"] = input_df.copy()  # ✅ ADD THIS
#     st.markdown("### 📄 Uploaded Data Preview")
#     st.dataframe(input_df.head(), use_container_width=True)

#     df = input_df.copy()
#     for col in categorical_cols:
#         df[col] = df[col].apply(lambda x: safe_transform(label_encoders[col], x))

#     for col in features_list:
#         if col not in df.columns:
#             df[col] = 0
#     df_features = df[features_list]

#     scaled = scaler.transform(df_features)
#     risk_probs = risk_model.predict(scaled).flatten()
#     risks = [classify_risk(p) for p in risk_probs]
#     clusters = kmeans.predict(scaled)
#     actions = [recommend_action(r, c) for r, c in zip(risks, clusters)]

#     input_df['predicted_risk'] = [ ["Low", "Medium", "High"][r] for r in risks ]
#     input_df['risk'] = risks
#     input_df['cluster'] = clusters
#     input_df['recommended_action'] = actions

#     # ✅ Save in session
#     st.session_state["predicted_data"] = input_df
#     st.session_state["risk_df"] = input_df

#     # ✅ Show results
#     st.markdown("### ✅ Prediction Results")
#     st.dataframe(input_df, use_container_width=True)

#     st.markdown("### 🧠 Auto Summary")
#     summary_html, high_risk_percent, med_risk_percent, low_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch = generate_summary(input_df)
#     st.markdown(summary_html, unsafe_allow_html=True)

#     conclusion_html = generate_conclusion(high_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch)
#     st.markdown(conclusion_html, unsafe_allow_html=True)

#     st.download_button("⬇️ Download Prediction CSV", data=input_df.to_csv(index=False).encode("utf-8"), file_name="risk_output.csv")

# elif st.session_state.get("predicted_data") is not None and st.session_state.get("original_input_df") is not None:
#     input_df = st.session_state["original_input_df"]
#     predicted_df = st.session_state["predicted_data"]

#     st.markdown("### 📄 Uploaded Data Preview")
#     st.dataframe(input_df.head(), use_container_width=True)

#     st.markdown("### ✅ Prediction Results")
#     st.dataframe(predicted_df, use_container_width=True)

#     st.markdown("### 🧠 Auto Summary")
#     summary_html, high_risk_percent, med_risk_percent, low_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch = generate_summary(predicted_df)
#     st.markdown(summary_html, unsafe_allow_html=True)

#     conclusion_html = generate_conclusion(high_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch)
#     st.markdown(conclusion_html, unsafe_allow_html=True)

#     st.download_button("⬇️ Download Prediction CSV", data=predicted_df.to_csv(index=False).encode("utf-8"), file_name="risk_output.csv")


# # ✅ Default intro
# else:
#     st.markdown("### 🚀 Let's Get Started")
#     st.markdown("Upload a customer dataset from the sidebar to begin prediction, analysis, and summary generation.")
import streamlit as st
import pandas as pd
import numpy as np
import os
import pickle
from keras.models import load_model
from transformers import T5Tokenizer, T5ForConditionalGeneration
import torch

# ----------------------------
# SESSION INITIALIZATION
# ----------------------------
if 'predicted_data' not in st.session_state:
    st.session_state.predicted_data = None

if 'risk_df' not in st.session_state:
    st.session_state.risk_df = None

# ----------------------------
# CONFIGURATION & THEME
# ----------------------------
st.set_page_config(page_title="\U0001F4CA NBFC Risk Predictor", layout="wide", page_icon="\U0001F4C8")

st.markdown("""
    <style>
        body {
            background-color: #f9f9f9;
            font-family: 'Segoe UI', sans-serif;
        }
        .main-title {
            text-align: center;
            color: #004080;
            font-size: 36px;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            font-size: 20px;
            color: #666;
            margin-bottom: 30px;
        }
        .stButton > button {
            background-color: #004080;
            color: white;
            border-radius: 8px;
            padding: 0.5em 2em;
            font-weight: bold;
        }
        .stDownloadButton > button {
            background-color: #008060;
            color: white;
            border-radius: 8px;
            padding: 0.5em 2em;
            font-weight: bold;
        }
        .success {
            background-color: #d4edda;
            padding: 15px;
            border-left: 6px solid #28a745;
            border-radius: 5px;
        }
        .info-card {
            background-color: #e8f0fe;
            padding: 20px;
            border-radius: 10px;
            border-left: 6px solid #4285F4;
            margin-bottom: 20px;
        }
    </style>
""", unsafe_allow_html=True)

st.markdown("<div class='main-title'>\U0001F4CA FinScope AI : \U0001F9E0  Intelligent Risk Analysis & Advisor</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Upload customer data, analyze risks, and view actionable insights!</div>", unsafe_allow_html=True)

st.sidebar.image("https://cdn-icons-png.flaticon.com/512/1077/1077114.png", width=100)
st.sidebar.markdown("### \U0001F4C1 Upload customer dataset Of Manappuram Finance")
uploaded_file = st.sidebar.file_uploader("Upload a CSV or Excel file", type=["csv", "xlsx"])

@st.cache_resource
def load_flan_model():
    tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-base")
    model = T5ForConditionalGeneration.from_pretrained("google/flan-t5-base")
    return tokenizer, model

tokenizer, flan_model = load_flan_model()

risk_model = load_model("risk_model.h5")
scaler = pickle.load(open("scaler.pkl", "rb"))
kmeans = pickle.load(open("kmeans.pkl", "rb"))
label_encoders = pickle.load(open("label_encoders.pkl", "rb"))
features_list = pickle.load(open("features_list.pkl", "rb"))

categorical_cols = [
    "EMI_PERSON_GENDER", "LOCALITY", "STATE_NAME", "BRANCH_NAME",
    "REGION_NAME", "TOPUP_LOAN_ORNOT", "CUSTOMER_PROFILE", "ENDUSE"
]

def classify_risk(prob):
    if prob <= 0.3:
        return 0
    elif prob <= 0.7:
        return 1
    else:
        return 2

def recommend_action(risk, cluster):
    if risk == 2:
        return "Legal Action"
    elif risk == 1:
        return ["Visit Customer", "Call Customer", "Send SMS Reminder"][cluster]
    else:
        return ["Send SMS Reminder", "Call Customer", "No Action Needed"][cluster]

def safe_transform(le, value):
    if value in le.classes_:
        return le.transform([value])[0]
    if 'Other' not in le.classes_:
        le.classes_ = np.append(le.classes_, 'Other')
    return le.transform(['Other'])[0]

def generate_summary(df):
    total = df.shape[0]
    risk_counts = df['predicted_risk'].value_counts().to_dict()

    high_risk = risk_counts.get('High', 0)
    med_risk = risk_counts.get('Medium', 0)
    low_risk = risk_counts.get('Low', 0)

    high_risk_percent = round(high_risk / total * 100, 1)
    med_risk_percent = round(med_risk / total * 100, 1)
    low_risk_percent = round(low_risk / total * 100, 1)

    high_loan_amt_count = df[df['LOAN_AMOUNT'] > 500000].shape[0] if 'LOAN_AMOUNT' in df else 0
    most_high_risk_cluster = df[df['predicted_risk'] == 'High']['cluster'].mode()[0]

    def get_top(col, risk_type):
        if col in df.columns:
            subset = df[df['predicted_risk'] == risk_type]
            return subset[col].mode()[0] if not subset[col].empty else "N/A"
        return "N/A"

    top_high_state = get_top("STATE_NAME", "High")
    top_med_state = get_top("STATE_NAME", "Medium")
    top_low_state = get_top("STATE_NAME", "Low")

    top_high_region = get_top("REGION_NAME", "High")
    top_med_region = get_top("REGION_NAME", "Medium")
    top_low_region = get_top("REGION_NAME", "Low")

    top_high_branch = get_top("BRANCH_NAME", "High")
    top_med_branch = get_top("BRANCH_NAME", "Medium")
    top_low_branch = get_top("BRANCH_NAME", "Low")

    summary = f"""
    <div class='info-card'>
    <b>\U0001F4CA Summary Report:</b><br><br>
    Out of <b>{total}</b> customers analyzed:<br>
    🔵 <b>{low_risk_percent}%</b> are classified as Low Risk<br>
    🟡 <b>{med_risk_percent}%</b> as Medium Risk<br>
    🔴 <b>{high_risk_percent}%</b> as High Risk<br><br>
    💰 <b>{high_loan_amt_count}</b> customers have loan amounts over ₹5 Lakhs<br><br>
    ⚠ Cluster <b>{most_high_risk_cluster}</b> has the highest number of High Risk customers — Suggested: <span style='color:red;'><b>Legal Action</b></span><br><br>

    📍 <b>Top Locations by Risk:</b><br>
    🔴 High Risk → State: <b>{top_high_state}</b>, Region: <b>{top_high_region}</b>, Branch: <b>{top_high_branch}</b><br>
    🟡 Medium Risk → State: <b>{top_med_state}</b>, Region: <b>{top_med_region}</b>, Branch: <b>{top_med_branch}</b><br>
    🔵 Low Risk → State: <b>{top_low_state}</b>, Region: <b>{top_low_region}</b>, Branch: <b>{top_low_branch}</b><br>
    </div>
    """
    return summary, high_risk_percent, med_risk_percent, low_risk_percent, high_loan_amt_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch

def generate_conclusion(df, high_risk_percent, high_balance_count, most_high_risk_cluster, top_state_high, top_region_high, top_branch_high):
    def get_top_location(risk_label, column):
        return (
            df[df['predicted_risk'] == risk_label][column].mode().iloc[0]
            if column in df.columns and not df[df['predicted_risk'] == risk_label][column].empty
            else "Unknown"
        )

    top_state_low = get_top_location('Low', 'STATE_NAME')
    top_region_low = get_top_location('Low', 'REGION_NAME')
    top_branch_low = get_top_location('Low', 'BRANCH_NAME')

    conclusion = f"""
    <div class='info-card' style='border-left:6px solid #dc3545;background-color:#f8d7da;'>
    <b>\U0001F9FE Conclusion & Strategic Suggestions:</b><br><br>

    <b>📌 High Risk Focus:</b><br>
    🔴 <b>{high_risk_percent}%</b> customers are in the High Risk category.<br>
    ➔ Concentrated in <b>State:</b> {top_state_high}, <b>Region:</b> {top_region_high}, <b>Branch:</b> {top_branch_high}.<br>
    ➔ Recommend <b>legal notices, recovery actions, and field visits</b> for Cluster <b>{most_high_risk_cluster}</b>.<br><br>

    <b>💰 High Loan Exposure:</b><br>
    ➔ <b>{high_balance_count}</b> customers have loans over ₹5 Lakhs. Prioritize for <b>collection, restructuring, or review.</b><br><br>

    <b>✅ Low Risk Opportunities:</b><br>
    ➔ Strong performance in <b>State:</b> {top_state_low}, <b>Region:</b> {top_region_low}, <b>Branch:</b> {top_branch_low}.<br>
    ➔ Suggest targeting these zones for <b>cross-selling, top-up offers, or digital engagement.</b><br><br>

    <b>🛡️ Actionable Tips:</b><br>
    • Audit high-risk branches more frequently<br>
    • Deploy dedicated recovery teams in risk-heavy zones<br>
    • Enhance pre-loan checks and digital verification<br><br>

    <b>📈 Business Impact:</b><br>
    Proactive targeting improves <b>portfolio quality</b>, <b>reduces defaults</b>, and <b>increases recovery efficiency</b>.
    </div>
    """
    return conclusion

if uploaded_file:
    st.markdown("<div class='success'>✅ File uploaded successfully. Running predictions...</div>", unsafe_allow_html=True)
    input_df = pd.read_csv(uploaded_file) if uploaded_file.name.endswith(".csv") else pd.read_excel(uploaded_file)
    st.session_state["original_input_df"] = input_df.copy()
    st.markdown("### 📄 Uploaded Data Preview")
    st.dataframe(input_df.head(), use_container_width=True)

    df = input_df.copy()
    for col in categorical_cols:
        df[col] = df[col].apply(lambda x: safe_transform(label_encoders[col], x))

    for col in features_list:
        if col not in df.columns:
            df[col] = 0
    df_features = df[features_list]

    scaled = scaler.transform(df_features)
    risk_probs = risk_model.predict(scaled).flatten()
    risks = [classify_risk(p) for p in risk_probs]
    clusters = kmeans.predict(scaled)
    actions = [recommend_action(r, c) for r, c in zip(risks, clusters)]

    input_df['predicted_risk'] = [ ["Low", "Medium", "High"][r] for r in risks ]
    input_df['risk'] = risks
    input_df['cluster'] = clusters
    input_df['recommended_action'] = actions

    st.session_state["predicted_data"] = input_df
    st.session_state["risk_df"] = input_df

    st.markdown("### ✅ Prediction Results")
    st.dataframe(input_df, use_container_width=True)

    st.markdown("### 🧠 Auto Summary")
    summary_html, high_risk_percent, med_risk_percent, low_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch = generate_summary(input_df)
    st.markdown(summary_html, unsafe_allow_html=True)

    conclusion_html = generate_conclusion(input_df, high_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch)
    st.markdown(conclusion_html, unsafe_allow_html=True)

    st.download_button("⬇️ Download Prediction CSV", data=input_df.to_csv(index=False).encode("utf-8"), file_name="risk_output.csv")

elif st.session_state.get("predicted_data") is not None and st.session_state.get("original_input_df") is not None:
    input_df = st.session_state["original_input_df"]
    predicted_df = st.session_state["predicted_data"]

    st.markdown("### 📄 Uploaded Data Preview")
    st.dataframe(input_df.head(), use_container_width=True)

    st.markdown("### ✅ Prediction Results")
    st.dataframe(predicted_df, use_container_width=True)

    st.markdown("### 🧠 Auto Summary")
    summary_html, high_risk_percent, med_risk_percent, low_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch = generate_summary(predicted_df)
    st.markdown(summary_html, unsafe_allow_html=True)

    conclusion_html = generate_conclusion(predicted_df, high_risk_percent, high_balance_count, most_high_risk_cluster, top_high_state, top_high_region, top_high_branch)
    st.markdown(conclusion_html, unsafe_allow_html=True)

    st.download_button("⬇️ Download Prediction CSV", data=predicted_df.to_csv(index=False).encode("utf-8"), file_name="risk_output.csv")

else:
    st.markdown("### 🚀 Let's Get Started")
    st.markdown("Upload a customer dataset from the sidebar to begin prediction, analysis, and summary generation.")
